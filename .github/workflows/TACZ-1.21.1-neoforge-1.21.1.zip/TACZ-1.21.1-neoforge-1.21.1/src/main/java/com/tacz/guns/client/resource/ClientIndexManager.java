package com.tacz.guns.client.resource;

import com.github.mcmodderanchor.simplebedrockmodel.v1.client.handler.FirstPersonRenderHandler;
import com.google.common.collect.Maps;
import com.tacz.guns.GunMod;
import com.tacz.guns.api.TimelessAPI;
import com.tacz.guns.api.client.gameplay.IClientPlayerGunOperator;
import com.tacz.guns.api.item.IAmmo;
import com.tacz.guns.api.item.IAttachment;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.client.resource.index.ClientAmmoIndex;
import com.tacz.guns.client.resource.index.ClientAttachmentIndex;
import com.tacz.guns.client.resource.index.ClientBlockIndex;
import com.tacz.guns.client.resource.index.ClientGunIndex;
import com.tacz.guns.resource.modifier.AttachmentPropertyManager;
import com.tacz.guns.resource.pojo.AmmoIndexPOJO;
import com.tacz.guns.resource.pojo.AttachmentIndexPOJO;
import com.tacz.guns.resource.pojo.BlockIndexPOJO;
import com.tacz.guns.resource.pojo.GunIndexPOJO;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import java.util.Map;
import java.util.Set;

@OnlyIn(Dist.CLIENT)
public class ClientIndexManager {
    private static final int HOTBAR_SLOT_COUNT = 9;

    public static final Map<ResourceLocation, GunDisplayInstance> GUN_DISPLAY = Maps.newHashMap();
    public static final Map<ResourceLocation, ClientGunIndex> GUN_INDEX = Maps.newHashMap();
    public static final Map<ResourceLocation, ClientAmmoIndex> AMMO_INDEX = Maps.newHashMap();
    public static final Map<ResourceLocation, ClientAttachmentIndex> ATTACHMENT_INDEX = Maps.newHashMap();
    public static final Map<ResourceLocation, ClientBlockIndex> BLOCK_INDEX = Maps.newHashMap();

    public static void clear() {
        GUN_DISPLAY.clear();
        GUN_INDEX.clear();
        AMMO_INDEX.clear();
        ATTACHMENT_INDEX.clear();
        BLOCK_INDEX.clear();
    }

    public static void reload() {
        clear();

        loadGunDisplay();
        loadGunIndex();
        loadAmmoIndex();
        loadAttachmentIndex();
        loadBlockIndex();
        warmUpInventoryModels();

        LocalPlayer player = Minecraft.getInstance().player;
        if (player != null && IGun.mainHandHoldGun(player)) {
            AttachmentPropertyManager.postChangeEvent(player, player.getMainHandItem());

            // 自动切一次枪，以便刷新状态机
            IClientPlayerGunOperator.fromLocalPlayer(player).draw(ItemStack.EMPTY);
            // FIXME: FirstPersonRenderHandler.reset();
        }
    }

    public static void loadGunIndex() {
        TimelessAPI.getAllCommonGunIndex().forEach(index -> {
            ResourceLocation id = index.getKey();
            GunIndexPOJO pojo = index.getValue().getPojo();
            try {
                GUN_INDEX.put(id, ClientGunIndex.getInstance(pojo));
            } catch (IllegalArgumentException exception) {
                GunMod.LOGGER.warn("{} index file read fail!", id, exception);
            }
        });
    }

    public static void loadGunDisplay() {
        ClientAssetsManager.INSTANCE.getGunDisplays().forEach(entry -> {
            ResourceLocation displayId = entry.getKey();
            try {
                GUN_DISPLAY.put(displayId, GunDisplayInstance.create(displayId, entry.getValue()));
            } catch (IllegalArgumentException exception) {
                GunMod.LOGGER.warn("{} display file read fail!", displayId, exception);
            }
        });
    }

    public static GunDisplayInstance getOrCreateGunDisplay(ResourceLocation displayId) {
        GunDisplayInstance instance = GUN_DISPLAY.get(displayId);
        if (instance != null) {
            return instance;
        }
        GunMod.LOGGER.warn("{} display instance is missing from cache", displayId);
        return null;
    }

    public static void loadAmmoIndex() {
        TimelessAPI.getAllCommonAmmoIndex().forEach(index -> {
            ResourceLocation id = index.getKey();
            AmmoIndexPOJO pojo = index.getValue().getPojo();
            try {
                AMMO_INDEX.put(id, ClientAmmoIndex.getInstance(pojo));
            } catch (IllegalArgumentException exception) {
                GunMod.LOGGER.warn("{} index file read fail!", id, exception);
            }
        });
    }

    public static void loadAttachmentIndex() {
        TimelessAPI.getAllCommonAttachmentIndex().forEach(index -> {
            ResourceLocation id = index.getKey();
            AttachmentIndexPOJO pojo = index.getValue().getPojo();
            try {
                ATTACHMENT_INDEX.put(id, ClientAttachmentIndex.getInstance(id, pojo));
            } catch (IllegalArgumentException exception) {
                GunMod.LOGGER.warn("{} index file read fail!", id, exception);
            }
        });
    }

    public static void loadBlockIndex() {
        TimelessAPI.getAllCommonBlockIndex().forEach(index -> {
            ResourceLocation id = index.getKey();
            BlockIndexPOJO pojo = index.getValue().getPojo();
            try {
                BLOCK_INDEX.put(id, ClientBlockIndex.getInstance(pojo));
            } catch (IllegalArgumentException exception) {
                GunMod.LOGGER.warn("{} index file read fail!", id, exception);
            }
        });
    }

    public static Set<Map.Entry<ResourceLocation, ClientGunIndex>> getAllGuns() {
        return GUN_INDEX.entrySet();
    }

    public static Set<Map.Entry<ResourceLocation, ClientAmmoIndex>> getAllAmmo() {
        return AMMO_INDEX.entrySet();
    }

    public static Set<Map.Entry<ResourceLocation, ClientAttachmentIndex>> getAllAttachments() {
        return ATTACHMENT_INDEX.entrySet();
    }

    public static Set<Map.Entry<ResourceLocation, ClientBlockIndex>> getAllBlocks() {
        return BLOCK_INDEX.entrySet();
    }

    public static void warmUpInventoryModels() {
        LocalPlayer player = Minecraft.getInstance().player;
        if (player == null) {
            return;
        }
        warmUpItemForUse(player.getMainHandItem());
        warmUpItemForUse(player.getOffhandItem());
        warmUpHotbarModels(player);
        warmUpBackpackModels(player);
    }

    public static void warmUpEquippedAndHotbarModels() {
        LocalPlayer player = Minecraft.getInstance().player;
        if (player == null) {
            return;
        }
        warmUpItemForUse(player.getMainHandItem());
        warmUpItemForUse(player.getOffhandItem());
        warmUpHotbarModels(player);
    }

    public static void warmUpBackpackModels() {
        LocalPlayer player = Minecraft.getInstance().player;
        if (player == null) {
            return;
        }
        warmUpBackpackModels(player);
    }

    private static void warmUpHotbarModels(LocalPlayer player) {
        var items = player.getInventory().items;
        int hotbarSize = Math.min(HOTBAR_SLOT_COUNT, items.size());
        for (int i = 0; i < hotbarSize; i++) {
            warmUpItemModel(items.get(i));
        }
    }

    private static void warmUpBackpackModels(LocalPlayer player) {
        var items = player.getInventory().items;
        for (int i = Math.min(HOTBAR_SLOT_COUNT, items.size()); i < items.size(); i++) {
            warmUpItemModel(items.get(i));
        }
    }

    public static void warmUpItem(ItemStack stack) {
        warmUpItemForUse(stack);
    }

    public static void warmUpItemModel(ItemStack stack) {
        if (stack.isEmpty()) {
            return;
        }
        if (stack.getItem() instanceof IGun) {
            TimelessAPI.getGunDisplay(stack).ifPresent(display -> {
                display.warmUpLod();
                display.warmUpModel();
                display.warmUpRuntime();
            });
            return;
        }
        IAttachment attachment = IAttachment.getIAttachmentOrNull(stack);
        if (attachment != null) {
            TimelessAPI.getClientAttachmentIndex(attachment.getAttachmentId(stack)).ifPresent(ClientAttachmentIndex::warmUp);
            return;
        }
        IAmmo ammo = IAmmo.getIAmmoOrNull(stack);
        if (ammo != null) {
            TimelessAPI.getClientAmmoIndex(ammo.getAmmoId(stack)).ifPresent(ClientAmmoIndex::warmUp);
        }
    }

    public static void warmUpItemForUse(ItemStack stack) {
        if (stack.isEmpty()) {
            return;
        }
        if (stack.getItem() instanceof IGun) {
            TimelessAPI.getGunDisplay(stack).ifPresent(display -> {
                display.warmUpLod();
                display.warmUpModel();
                display.warmUpRuntime();
            });
            return;
        }
        warmUpItemModel(stack);
    }
}